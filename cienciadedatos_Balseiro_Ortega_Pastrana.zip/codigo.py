def leer(x, y, fichero, k):
    #_____________________________________________________
    f = open(str(fichero), "r")
    s = 0
    while (True):

        n = []
        a = 0
        i = 0
        suma = ""
        while (True):
            a = f.read(1)
            if (a == ";"):
                break
            n.append(str(a))
            i = i + 1

        for j in range(0, i):
            suma = suma + n[j]
        x.append(float(suma))

        #_____________________________________________________

        suma = ""
        i = 0
        n = []
        a = 0
        while (True):
            a = f.read(1)
            if (a == ";"):
                break
            n.append(a)
            i = i + 1

        for j in range(0, i):
            suma = suma + n[j]
        y.append(float(suma))

        s = s + 1
        if (k == s):
            break
