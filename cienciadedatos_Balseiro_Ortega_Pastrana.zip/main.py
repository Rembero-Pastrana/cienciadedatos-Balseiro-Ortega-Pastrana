import numpy as np
import codigo as lb
n= int(input("digite el numero de datos: "))
s=int(input("digite grado del polinomio <n-2: "))
m=s+1

x=[]
y=[]

matriz=[]
vecsolucion=[]
for i in range(0, 2*n):
  matriz.append(0)
matrizregrecion=np.zeros((m,m))
vecsolucion=np.zeros((m,1))

fichero="fichero.txt"
lb.leer(x,y,fichero,n)












for j in range(0, 2*n):
  suma=0
  
  for i in range(0, n):
    suma=suma+pow(x[i], j)

  matriz[j]=suma


#vector solucion
for j in range(0, m):
  suma=0
  
  for i in range(0, n):
    suma=suma+pow(x[i], j)*y[i]

  vecsolucion[j,0]=suma

  
#matriz
z=0

for j in range(0, m):

  for i in range(0, m):
    matrizregrecion[j,i]=matriz[i+z]
  z=z+1



a=np.matrix(matrizregrecion, dtype=float)
b=np.matrix(vecsolucion, dtype=float)
#coe=a**(-1)*b
coe=np.linalg.solve(matrizregrecion,vecsolucion)

"""
print(a)
print (b)
print (matriz)

print("la matriz de regrecion es ")
print (a)
print("los terminos independientes de la matriz son ")
print (b)


print("los coeficientes del polinomio de regrecion son= ")
print (coe)
"""
print ("el polinomio de regresion es: ")

if m==2:
  print (coe[0,0],"+",coe[1,0],"t")
if m==3:
  print (coe[0,0],"+",coe[1,0],"t+",coe[2,0],"t^2")
if m==4:
  print (coe[0,0],"+",coe[1,0],"t+",coe[2,0],"t^2",coe[3,0],"t^3")
if m==2:
  proyeccion=int(input("digite año de proyeccio: "))
  auxiliar=proyeccion-x[n-1]
  contador=int(auxiliar)
  for j in range(1, contador+1):
      tpda=coe[0,0]+coe[1,0]*(x[n-1]+j)
      tpda=int(tpda)
      print ("el TPDA para año",x[n-1]+j," es: ", tpda)

